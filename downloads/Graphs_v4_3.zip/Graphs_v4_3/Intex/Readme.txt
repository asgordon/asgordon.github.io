
Intex Finite State Transducers for Commonsense Psychological Concepts

Version 4: Monday September 20, 2004

Andrew S. Gordon
Institute for Creative Technologies
University of Southern California
gordon@ict.usc.edu


This folder contains 529 finite state transducers in .grf format created using the Intex Corpus Processor version 4.
The file ALL_CONCEPTS.grf contains the graphs of all the concepts as they were created.
The file ALL_CONCEPTS.fst contains a minimal FST that can be used for efficient searching and tagging of text. (9556 states, 85153 transitions)

Version 4.1: Thursday October 14, 2004

Minor bug fixes. New FST has 9529 states, and 84946 transitions.

Version 4.2: Feb 1, 2005

Tried to gather up the absolute most recent versions, but still basically the same as the September 20, 2004 release.
