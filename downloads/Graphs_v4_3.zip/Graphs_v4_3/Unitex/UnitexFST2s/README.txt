Readme FST2_v4_2.zip
Compiled Unitex FST2 finite state transducers for 30 representational areas, plus one combined "all concepts" fst2.
Based on Intex graphs version 4_2.
Made available Nov 3, 2004 by Andrew Gordon.
