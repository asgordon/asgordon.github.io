
readme.txt
----------

/icwsm09stories/icwsm09stories.txt

The file "icwsm09stories.txt" contains the locations of 960,098 personal stories in the ICWSM 2009 Spinn3r Dataset. This dataset was created for the 2009 International Conference on Weblogs and Social Media, ICWSM 2009 Data Challenge.

The format of the file is as follows. Each line in the file is one record consisting of 6 tab-delimited fields. The columns are as follows:

0. A sequential story ID, which is assigned by us
1. The name of a file in the ICWSM 2009 Spinn3r Dataset distribution.
2. The 1-based line number that begins the XML of a story entry.
3. The number of lines in the story entry.
4. The confidence value of the confidence-weighted linear classifier
5. A "+" if the description field contained more than 250 characters, otherwise a "-"

/icwsm09stories/ICWSM09-DCW.PDF

The file "ICWSM09-DCW.PDF" is the paper that was presented at the ICWSM 2009 Data Challenge Workshop. Please use the following citation when referencing this research.

Gordon, A. & Swanson, R. (2009) Identifying Personal Stories in Millions of Weblog Entries. Third International Conference on Weblogs and Social Media, Data Challenge Workshop, San Jose, CA, May 20, 2009.

/icwsm09stories/DatasetFilter.java

The file "DatasetFilter.java" is a short java program that can be used to filter the entire ICWSM 2009 Spinn3r Dataset to produce a corpus of 960,098 weblog entries that we have classified as stories, in their original XML format. To compile this program, try "javac DatasetFilter.java" from a terminal window prompt. To run this program, first uncompress the entire ICWSM 2009 Spinn3r Dataset on your hard drive. Open a terminal window and change your directory to the location of all of the tiergroup folders. The compiled java program should be put here too, along with the file "icwsm09stories.txt".  Then try "java DatasetFilter icwsm09stories.txt > icwsm09stories.xml". This will create a single file containing each of the XML entries that are stories, consisting of exactly 4,674,885,460 bytes. If you do not like to use Unix pipes (the ">" directive), then feel free to rewrite this java program to take another argument as the destination file.


Questions can be directed to:

Andrew S. Gordon
Institute for Creative Technologies
University of Southern California
gordon@ict.usc.edu

v1.0 May 29, 2009: Initial release
v1.1 June 15, 2009: Fixed 1-off errors in both index file and java extractor.

