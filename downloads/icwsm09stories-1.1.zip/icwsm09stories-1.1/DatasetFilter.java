import java.io.*;

// A simple utility for filtering the ICWSM09 Data Challenge corpus
// Requires one argument as input, which should be icwsm09stories.txt
// The optional second argument specifies the top directory of the blog corpus (the one that contains tiergroup-XXXX subdirectories)
// If the second argument is not given, this program must be run in the directory that contains the tiergroup-XXXX subdirectories
// Usage: java DatasetFilter icwsm09stories.txt [path/to/tiergroup/parent] > icwsm09stories.xml
public class DatasetFilter
{
	public static void main(String[] args)
	{
		// Get corpus directory...default to current directory
		String corpusDirectory = ".";
		if(args.length > 1)
			corpusDirectory = args[1];

		// Make sure corpus directory ends with the path separator
		if(corpusDirectory.charAt(corpusDirectory.length() - 1) != File.separatorChar)
			corpusDirectory += File.separatorChar;			

		int recordsProcessed = 0;
		
		try	
		{
			// Start root element
			System.out.println("<items>");
			System.out.println();
			
			// Iterate over the story records
			int lastStartLine = -1;
			String currentXmlFilename = null;
			LineNumberReader xmlFile = null;
			BufferedReader records = new BufferedReader(new FileReader(args[0]));
			String record;	
			while ((record = records.readLine()) != null)
			{
				// Get record info
				String[] parts = record.split("\t");
				String xmlFilename = corpusDirectory + parts[1];
				int startLine = new Integer(parts[2]).intValue();
				int numLines = new Integer(parts[3]).intValue();
				int endLine = startLine + numLines - 1;

				// Change files if needed
				if (!xmlFilename.equals(currentXmlFilename))
				{
					// Close existing XML file if it is open
					if(xmlFile != null)
						xmlFile.close();

					// Set current XML file and open it
					currentXmlFilename = xmlFilename;
					xmlFile = new LineNumberReader(new FileReader(currentXmlFilename));

					lastStartLine = -1;
				}

				// Start lines in the records should be increasing
				if(startLine < lastStartLine)
					throw new Exception("Non-increasing start lines");

				// Make sure the desired start line is after current line
				int currentLine = xmlFile.getLineNumber() + 1;
				if(startLine < currentLine)
					throw new Exception("Looking for start line that is before current line");

				// Iterate through lines in current file
				while (currentLine <= endLine)
				{
					String line = xmlFile.readLine();

					// Write comment for the start of an entry
					if (currentLine == startLine)
					{
						System.out.printf("<!-- %s %s %s %s %s %s -->", parts[0],parts[1],parts[2],parts[3],parts[4],parts[5]);
						System.out.println();

						// Make sure we're at a valid item start
						String trimmed = line.trim();
						if(!trimmed.equals("<item>"))
							throw new Exception("Invalid start line for item " + (recordsProcessed + 1) + ":  " + line);				
					}

					// Write entry line	
					if (currentLine >= startLine)
						System.out.println(line);

					// Make sure we ended at a valid item end
					if(currentLine == endLine)
					{
						String trimmed = line.trim();
						if(!trimmed.equals("</item>"))
							throw new Exception("Invalid end line for item" + (recordsProcessed + 1) + ":  " + line);
					}				

					// Update current line
					currentLine = xmlFile.getLineNumber() + 1;
				}

				// Print blank line before next entry
				System.out.println();

				// Print status every 10k records
				if((++recordsProcessed % 10000) == 0)
					System.err.println("Processed " + recordsProcessed + " entries...");

				lastStartLine = startLine;
			}
			
			// Close root element
			System.out.println("</items>");
			
			// Close open files
			xmlFile.close();
			records.close();

			System.err.println("Finished. Processed " + recordsProcessed + " entries.");
		}
		catch (Exception e) 
		{
			System.err.println("Exception caught after " + recordsProcessed + " records were processed:  " + e.getMessage());
			e.printStackTrace();
		}
	}
}